﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'af', {
	copy: 'Kopiereg &copy; $1. Alle regte voorbehou.',
	dlgTitle: 'Meer oor CKEditor 4',
	moreInfo: 'Vir lisensie-informasie, besoek asb. ons webwerf:'
} );
