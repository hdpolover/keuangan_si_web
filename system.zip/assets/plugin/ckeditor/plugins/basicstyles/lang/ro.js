﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'ro', {
	bold: 'Îngroşat (bold)',
	italic: 'Înclinat (italic)',
	strike: 'Tăiat (strike through)',
	subscript: 'Indice (subscript)',
	superscript: 'Putere (superscript)',
	underline: 'Subliniat (underline)'
} );
